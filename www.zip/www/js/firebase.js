
const firebaseConfig = {
  apiKey: "AIzaSyAlrTyZaxlOF7l9FDqd-kueMTUK377iAFA",
  authDomain: "cordova-6d020.firebaseapp.com",
  projectId: "cordova-6d020",
  storageBucket: "cordova-6d020.appspot.com",
  messagingSenderId: "28691661938",
  appId: "1:28691661938:web:585222923babb867ba2eeb",
  measurementId: "G-Z5PFT1RPB1"
};

firebase.initializeApp(firebaseConfig);
firebase.analytics();